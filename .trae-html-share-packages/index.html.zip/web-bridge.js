(function (global) {
  'use strict';

  var BRIDGE_SOURCE = 'mineradio-extension-bridge';
  var PAGE_SOURCE = 'mineradio-web-page';
  var REQUEST_TIMEOUT_MS = 45000;
  var bridgeReady = false;
  var bridgeVersion = '';
  var pendingRequests = new Map();
  var requestSeq = 0;
  var blobUrlCache = new Map();
  var beatmapCache = {};
  var fetchPatched = false;
  var apiJsonPatched = false;

  function isDesktopApp() {
    return !!(global.desktopWindow && global.desktopWindow.isDesktop);
  }

  function isPrivateLanHost(host) {
    host = String(host || '').toLowerCase();
    if (/^192\.168\.\d{1,3}\.\d{1,3}$/.test(host)) return true;
    if (/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(host)) return true;
    var m = /^172\.(\d{1,2})\.\d{1,3}\.\d{1,3}$/.exec(host);
    return !!(m && Number(m[1]) >= 16 && Number(m[1]) <= 31);
  }

  function isLocalDevServer() {
    var host = String(global.location && global.location.hostname || '').toLowerCase();
    return host === 'localhost' || host === '127.0.0.1' || host === '::1' || host === '[::1]' || isPrivateLanHost(host);
  }

  function bridgeHintHost() {
    var host = String(global.location && global.location.hostname || '');
    if (isPrivateLanHost(host)) return host + '（局域网）';
    if (host === '::1' || host === '[::1]') return '[::1]';
    return host || '当前页面';
  }

  function isWebModeEnabled() {
    if (isDesktopApp()) return false;
    try {
      var forced = global.localStorage.getItem('mineradio-web-mode-v1');
      if (forced === '0') return false;
      if (forced === '1') return true;
    } catch (_) {}
    return true;
  }

  function parseApiPath(url) {
    var raw = String(url || '');
    var path = raw;
    var query = {};
    try {
      var parsed = new URL(raw, global.location.origin);
      path = parsed.pathname;
      parsed.searchParams.forEach(function (value, key) {
        query[key] = value;
      });
    } catch (_) {
      var qIdx = raw.indexOf('?');
      if (qIdx >= 0) {
        path = raw.slice(0, qIdx);
        raw.slice(qIdx + 1).split('&').forEach(function (part) {
          var eq = part.indexOf('=');
          if (eq <= 0) return;
          query[decodeURIComponent(part.slice(0, eq))] = decodeURIComponent(part.slice(eq + 1));
        });
      }
    }
    return { path: path, query: query };
  }

  function postBridgeMessage(type, payload) {
    global.postMessage(Object.assign({ source: PAGE_SOURCE, type: type }, payload || {}), '*');
  }

  function compareBridgeSemver(a, b) {
    a = String(a || '0').replace(/^v/i, '').split('.').map(function (n) { return Number(n) || 0; });
    b = String(b || '0').replace(/^v/i, '').split('.').map(function (n) { return Number(n) || 0; });
    var len = Math.max(a.length, b.length);
    for (var i = 0; i < len; i++) {
      var av = a[i] || 0;
      var bv = b[i] || 0;
      if (av > bv) return 1;
      if (av < bv) return -1;
    }
    return 0;
  }

  function rememberBridgeExtId(extId) {
    extId = String(extId || '').trim();
    if (!extId) return;
    try { global.localStorage.setItem('mineradio-bridge-ext-id', extId); } catch (_) {}
  }

  function readBridgeExtId() {
    if (global.__mineradioBridgeExtId) return String(global.__mineradioBridgeExtId);
    try { return global.localStorage.getItem('mineradio-bridge-ext-id') || ''; } catch (_) {
      return '';
    }
  }

  function applyBridgeHandshake(data) {
    if (!data) return;
    bridgeReady = true;
    if (data.version) bridgeVersion = data.version;
    if (data.extId) rememberBridgeExtId(data.extId);
  }

  function refreshBridgeVersion(timeoutMs) {
    timeoutMs = Math.max(800, Number(timeoutMs) || 2500);
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        global.removeEventListener('message', onMessage);
        resolve({ ready: bridgeReady, version: bridgeVersion, extId: readBridgeExtId() });
      }, timeoutMs);
      function finish(hit) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        global.removeEventListener('message', onMessage);
        resolve(hit || { ready: bridgeReady, version: bridgeVersion, extId: readBridgeExtId() });
      }
      function onMessage(event) {
        if (event.source !== global || !event.data || event.data.source !== BRIDGE_SOURCE) return;
        if (event.data.type === 'MINERADIO_BRIDGE_READY' || event.data.type === 'MINERADIO_BRIDGE_PONG') {
          applyBridgeHandshake(event.data);
          finish({ ready: true, version: bridgeVersion, extId: readBridgeExtId() });
        }
      }
      global.addEventListener('message', onMessage);
      postBridgeMessage('MINERADIO_BRIDGE_PING');
      tryExternalBridgeProbe(true);
      setTimeout(function () { postBridgeMessage('MINERADIO_BRIDGE_PING'); }, 180);
    });
  }

  function waitForBridge(timeoutMs) {
    return probeBridge({ timeoutMs: timeoutMs || 3000, force: false }).then(function (hit) {
      return !!(hit && hit.ready);
    });
  }

  function probeBridge(options) {
    options = options || {};
    if (options.refreshVersion) return refreshBridgeVersion(options.timeoutMs);
    if (bridgeReady && !options.force) {
      return Promise.resolve({ ready: true, version: bridgeVersion, extId: readBridgeExtId() });
    }
    var timeoutMs = Math.max(1500, Number(options.timeoutMs) || 6000);
    var force = !!options.force;
    return new Promise(function (resolve) {
      var done = false;
      var attempt = 0;
      var maxAttempts = Math.max(4, Math.ceil(timeoutMs / 350));
      var timer = setTimeout(finish, timeoutMs);
      var pingTimer = null;

      function finish(result) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (pingTimer) clearInterval(pingTimer);
        global.removeEventListener('message', onMessage);
        resolve(result || { ready: bridgeReady, version: bridgeVersion, extId: readBridgeExtId() });
      }

      function onMessage(event) {
        if (event.source !== global || !event.data || event.data.source !== BRIDGE_SOURCE) return;
        if (event.data.type === 'MINERADIO_BRIDGE_READY' || event.data.type === 'MINERADIO_BRIDGE_PONG') {
          applyBridgeHandshake(event.data);
          finish({ ready: true, version: bridgeVersion, extId: readBridgeExtId() });
        }
      }

      function sendProbe() {
        if (global.__mineradioBridgeExtId && !readBridgeExtId()) {
          rememberBridgeExtId(global.__mineradioBridgeExtId);
        }
        postBridgeMessage('MINERADIO_BRIDGE_PING');
        if (force || attempt === 0 || attempt % 2 === 0) {
          postBridgeMessage('MINERADIO_BRIDGE_PROBE', { pageUrl: String(global.location && global.location.href || ''), force: force });
        }
        tryExternalBridgeProbe(force);
      }

      global.addEventListener('message', onMessage);
      sendProbe();
      pingTimer = setInterval(function () {
        attempt += 1;
        if (bridgeReady) {
          finish({ ready: true, version: bridgeVersion, extId: readBridgeExtId() });
          return;
        }
        if (attempt >= maxAttempts) {
          finish({ ready: false, version: bridgeVersion, extId: readBridgeExtId() });
          return;
        }
        sendProbe();
      }, 350);
    });
  }

  function tryExternalBridgeProbe(force) {
    var extId = readBridgeExtId();
    if (!extId || !global.chrome || !global.chrome.runtime || typeof global.chrome.runtime.sendMessage !== 'function') return false;
    try {
      global.chrome.runtime.sendMessage(extId, {
        type: 'MINERADIO_BRIDGE_PROBE',
        pageUrl: String(global.location && global.location.href || ''),
        force: !!force,
      }, function (resp) {
        if (global.chrome.runtime.lastError) return;
        if (resp && resp.ok) {
          applyBridgeHandshake({ version: resp.version, extId: resp.extId || extId });
        }
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  function extensionApiRequest(path, query, opts) {
    opts = opts || {};
    var id = 'req_' + (++requestSeq);
    var apiTimeout = opts.timeoutMs || opts.bridgeTimeoutMs ||
      ((path === '/api/audio' && query && query.purpose === 'analysis') ? 180000 : REQUEST_TIMEOUT_MS);
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(function () {
        pendingRequests.delete(id);
        reject(new Error('扩展 API 超时: ' + path));
      }, apiTimeout);
      pendingRequests.set(id, {
        resolve: function (payload) {
          clearTimeout(timer);
          resolve(payload);
        },
        reject: function (err) {
          clearTimeout(timer);
          reject(err);
        },
      });
      postBridgeMessage('MINERADIO_API', {
        id: id,
        payload: {
          path: path,
          method: opts.method || 'GET',
          query: query || {},
          body: opts.body || null,
          headers: opts.headers || null,
        },
      });
    });
  }

  function bufferToBlobUrl(buffer, contentType) {
    var bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer || []);
    var blob = new Blob([bytes], { type: contentType || 'application/octet-stream' });
    return URL.createObjectURL(blob);
  }

  function normalizeBinaryBuffer(raw) {
    if (!raw) return null;
    if (raw instanceof ArrayBuffer) return raw;
    if (ArrayBuffer.isView(raw)) return raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength);
    if (Array.isArray(raw)) return new Uint8Array(raw).buffer;
    return null;
  }

  function handleBinaryApiResponse(path, query, data) {
    if (!data || !data.__binary) return null;
    if (data.error) throw new Error(data.error);
    if (data.dataUrl && /^data:(image\/|application\/octet-stream)/i.test(data.dataUrl)) {
      return data.dataUrl;
    }
    var cacheKey = path + '?' + JSON.stringify(query || {});
    if (blobUrlCache.has(cacheKey)) return blobUrlCache.get(cacheKey);
    var buffer = normalizeBinaryBuffer(data.buffer);
    if (!buffer || !buffer.byteLength) return null;
    var blobUrl = bufferToBlobUrl(buffer, data.contentType);
    blobUrlCache.set(cacheKey, blobUrl);
    return blobUrl;
  }

  function localBeatmapGet(key) {
    return beatmapCache[key] || { ok: false, hit: false };
  }

  function localBeatmapSet(key, map) {
    beatmapCache[key] = { ok: true, hit: true, map: map };
    try {
      global.localStorage.setItem('mineradio-web-beatmap:' + key, JSON.stringify(map));
    } catch (_) {}
    return { ok: true };
  }

  function tryLoadBeatmapFromStorage(key) {
    if (beatmapCache[key]) return beatmapCache[key];
    try {
      var raw = global.localStorage.getItem('mineradio-web-beatmap:' + key);
      if (raw) {
        var map = JSON.parse(raw);
        beatmapCache[key] = { ok: true, hit: true, map: map };
        return beatmapCache[key];
      }
    } catch (_) {}
    return { ok: false, hit: false };
  }

  async function webApiJson(url, opts) {
    opts = opts || {};
    var parsed = parseApiPath(url);
    var path = parsed.path;
    var query = parsed.query;

    if (path === '/api/beatmap/cache/status') {
      return { ok: true, provider: 'web-local', enabled: true };
    }
    if (path === '/api/beatmap/cache' && (opts.method || 'GET').toUpperCase() === 'GET') {
      return tryLoadBeatmapFromStorage(query.key || '');
    }
    if (path === '/api/beatmap/cache' && (opts.method || 'GET').toUpperCase() === 'POST') {
      var body = opts.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch (_) { body = {}; }
      }
      return localBeatmapSet((body && body.key) || query.key || '', body && body.map);
    }

    var ready = await waitForBridge(opts.bridgeTimeoutMs || 10000);
    if (!ready) {
      throw new Error('未检测到 Mineradio Bridge 扩展（' + bridgeHintHost() + '）。请重新加载扩展后刷新页面；建议用 http://127.0.0.1:端口 而不是 [::1]。');
    }

    var apiOpts = Object.assign({}, opts);
    if (path === '/api/audio' && query.purpose === 'analysis' && !apiOpts.headers) {
      apiOpts.headers = { Range: 'bytes=0-2621439' };
    }
    var data = await extensionApiRequest(path, query, apiOpts);

    if (path === '/api/cover' || path === '/api/audio') {
      if (path === '/api/audio' && query.purpose === 'analysis') {
        if (data && data.__binary) {
          var analysisBuffer = normalizeBinaryBuffer(data.buffer);
          if (analysisBuffer && analysisBuffer.byteLength) {
            return {
              __binary: true,
              buffer: analysisBuffer,
              contentType: data.contentType || 'application/octet-stream',
            };
          }
        }
        if (query.url) {
          throw new Error('扩展未能代理音频，节奏分析不可用。请确认 Mineradio Bridge 已启用并刷新页面。');
        }
      }
      var blobUrl = handleBinaryApiResponse(path, query, data);
      if (path === '/api/audio' && !blobUrl && query.url) {
        if (query.purpose === 'analysis') {
          throw new Error('扩展未能代理音频，节奏分析不可用。请确认 Mineradio Bridge 已启用并刷新页面。');
        }
        return { url: query.url, direct: true };
      }
      if (blobUrl) {
        if (path === '/api/cover') return blobUrl;
        return { url: blobUrl, proxied: true };
      }
    }

    return data;
  }

  var coverResolveCache = new Map();

  function arrayBufferToDataUrl(buffer, contentType) {
    if (!buffer || !buffer.byteLength) return '';
    var bytes = new Uint8Array(buffer);
    var parts = [];
    var step = 0x8000;
    for (var i = 0; i < bytes.length; i += step) {
      parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + step)));
    }
    var mime = String(contentType || 'image/jpeg').split(';')[0].trim() || 'image/jpeg';
    if (!/^image\//i.test(mime)) mime = 'image/jpeg';
    return 'data:' + mime + ';base64,' + btoa(parts.join(''));
  }

  async function fetchCoverBinary(url, cacheBust) {
    var ready = await waitForBridge(12000);
    if (!ready) throw new Error('Bridge not ready');
    var query = { url: url };
    if (cacheBust) query.v = String(Date.now());
    return extensionApiRequest('/api/cover', query, { bridgeTimeoutMs: 15000 });
  }

  async function resolveWebCoverUrl(url, cacheBust) {
    if (!url || /^blob:/i.test(url) || /^data:/i.test(url)) return url;
    var cacheKey = url + (cacheBust ? ':bust' : '');
    if (coverResolveCache.has(cacheKey)) return coverResolveCache.get(cacheKey);
    var task = webApiJson('/api/cover?url=' + encodeURIComponent(url) + (cacheBust ? '&v=' + Date.now() : ''), { bridgeTimeoutMs: 15000 })
      .then(function (blobUrl) { return (typeof blobUrl === 'string' && blobUrl) ? blobUrl : url; })
      .catch(function () { return url; });
    coverResolveCache.set(cacheKey, task);
    return task;
  }
  global.__mineradioResolveCoverUrl = resolveWebCoverUrl;

  async function resolveWebCoverUrlForCanvas(url, cacheBust) {
    if (!url || /^data:image\//i.test(url)) return url || '';
    var cacheKey = 'canvas:' + url + (cacheBust ? ':bust' : '');
    if (coverResolveCache.has(cacheKey)) return coverResolveCache.get(cacheKey);
    var task = (async function () {
      try {
        var data = await fetchCoverBinary(url, cacheBust);
        if (data && data.error) throw new Error(data.error);
        if (data && data.dataUrl && /^data:image\//i.test(data.dataUrl)) return data.dataUrl;
        var dataUrl = arrayBufferToDataUrl(normalizeBinaryBuffer(data && data.buffer), data && data.contentType);
        if (dataUrl) return dataUrl;
      } catch (_) {}
      try {
        var blobUrl = await resolveWebCoverUrl(url, true);
        if (blobUrl && /^data:image\//i.test(blobUrl)) return blobUrl;
        if (blobUrl && /^blob:/i.test(blobUrl)) {
          var resp = await global.__mineradioNativeFetch(blobUrl);
          var blob = await resp.blob();
          return await new Promise(function (resolve, reject) {
            var reader = new FileReader();
            reader.onload = function () { resolve(reader.result || ''); };
            reader.onerror = function () { reject(reader.error || new Error('read blob failed')); };
            reader.readAsDataURL(blob);
          });
        }
      } catch (_) {}
      return '';
    })().then(function (resolved) {
      // Don't permanent-cache failures — Bridge/CORS fixes need a later retry.
      if (!resolved) coverResolveCache.delete(cacheKey);
      return resolved;
    });
    coverResolveCache.set(cacheKey, task);
    return task;
  }
  global.__mineradioResolveCoverUrlForCanvas = resolveWebCoverUrlForCanvas;

  async function webFetch(url, opts) {
    opts = opts || {};
    var parsed = parseApiPath(url);
    if (!parsed.path.startsWith('/api/')) {
      return global.__mineradioNativeFetch(url, opts);
    }
    var data = await webApiJson(url, opts);
    if (parsed.path === '/api/cover' && typeof data === 'string') {
      return {
        ok: true,
        json: function () { return Promise.resolve({ url: data }); },
        blob: function () { return global.__mineradioNativeFetch(data).then(function (r) { return r.blob(); }); },
      };
    }
    if (parsed.path === '/api/podcast/dj-beatmap') {
      return {
        ok: !!(data && data.ok),
        json: function () { return Promise.resolve(data); },
      };
    }
    return {
      ok: true,
      json: function () { return Promise.resolve(data); },
    };
  }

  global.addEventListener('message', function (event) {
    if (event.source !== global || !event.data || event.data.source !== BRIDGE_SOURCE) return;
    if (event.data.type === 'MINERADIO_BRIDGE_READY' || event.data.type === 'MINERADIO_BRIDGE_PONG') {
      applyBridgeHandshake(event.data);
      return;
    }
    if (event.data.type !== 'MINERADIO_API_RESPONSE') return;
    var pending = pendingRequests.get(event.data.id);
    if (!pending) return;
    pendingRequests.delete(event.data.id);
    if (event.data.ok) pending.resolve(event.data.data);
    else pending.reject(new Error(event.data.error || '扩展 API 失败'));
  });

  function patchFetchTransport() {
    if (fetchPatched || !isWebModeEnabled()) return false;
    global.__mineradioWebMode = true;
    global.__mineradioWebApiJson = webApiJson;
    global.__mineradioNativeFetch = global.fetch.bind(global);
    global.fetch = function (url, opts) {
      var parsed = parseApiPath(String(url || ''));
      if (parsed.path.startsWith('/api/')) return webFetch(url, opts);
      return global.__mineradioNativeFetch(url, opts);
    };
    fetchPatched = true;
    return true;
  }

  function patchApiJsonTransport() {
    if (apiJsonPatched || !isWebModeEnabled()) return false;
    if (typeof global.apiJson !== 'function') return false;
    var nativeApiJson = global.apiJson;
    global.__mineradioWebApiJson = webApiJson;
    global.apiJson = async function (url, opts) {
      var parsed = parseApiPath(url);
      if (parsed.path.startsWith('/api/')) return webApiJson(url, opts);
      return nativeApiJson(url, opts);
    };
    apiJsonPatched = true;
    return true;
  }

  function installWebShell() {
    if (!isWebModeEnabled()) return false;
    global.__mineradioWebMode = true;
    global.__mineradioWebBridge = {
      isReady: function () { return bridgeReady; },
      getVersion: function () { return bridgeVersion; },
      ping: waitForBridge,
      probe: probeBridge,
      refreshVersion: refreshBridgeVersion,
      compareVersion: compareBridgeSemver,
      needsUpdate: function (latest) {
        if (!bridgeVersion) return false;
        return compareBridgeSemver(bridgeVersion, latest || '0') < 0;
      },
    };
    document.documentElement.classList.add('web-shell-root');
    if (document.body) document.body.classList.add('web-shell');
    waitForBridge(5000).then(function (ready) {
      if (!ready) console.warn('[Mineradio Web] Bridge extension not detected.');
      else console.info('[Mineradio Web] Bridge ready', bridgeVersion);
    });
    return true;
  }

  global.__mineradioInstallWebTransport = function () {
    patchFetchTransport();
    patchApiJsonTransport();
    installWebShell();
  };

  global.__mineradioNotifyApiJsonReady = function () {
    if (patchApiJsonTransport() && apiJsonPoll) {
      clearInterval(apiJsonPoll);
      apiJsonPoll = null;
    }
  };

  function startBridgePingLoop() {
    var attempts = 0;
    var timer = setInterval(function () {
      if (bridgeReady || attempts++ >= 30) {
        clearInterval(timer);
        return;
      }
      postBridgeMessage('MINERADIO_BRIDGE_PING');
    }, 400);
  }

  // 关键：在 head 里立刻劫持 fetch，避免主脚本 startup 登录请求打到静态服务器 404
  patchFetchTransport();
  postBridgeMessage('MINERADIO_BRIDGE_PING');
  startBridgePingLoop();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      global.__mineradioInstallWebTransport();
    });
  } else {
    global.__mineradioInstallWebTransport();
  }

  var apiJsonPoll = setInterval(function () {
    if (patchApiJsonTransport()) clearInterval(apiJsonPoll);
  }, 16);
  setTimeout(function () { clearInterval(apiJsonPoll); }, 8000);
})(window);
