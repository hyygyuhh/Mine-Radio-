# Mineradio Bridge 更新日志

完整页面：https://mineradio.art/changelog.html

## 1.4.3 — 2026-11-03

- 网页退出时清除对应平台登录 Cookie
- 官网登录返回后自动同步登录状态
- 匿名统计静默上报（弹窗不展示）
- 修复重载扩展重复计入日活
- 统计接口：`https://mineradio.art/bridge/stats`
- 恢复正式扩展图标

## 1.4.2

- 弹窗与联系邮箱整理
- 登录状态展示优化

## 1.4.0 – 1.4.1

- 网易云 / QQ / 酷狗代理与歌单能力完善
- 媒体 Referer / 封面代理改进

## 1.3.1

- Bridge 基础 Cookie 代理与网页通信
