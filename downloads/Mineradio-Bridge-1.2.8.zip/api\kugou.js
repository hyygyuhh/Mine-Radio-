import CryptoJS from '../vendor/crypto-es.mjs';
import {
  getKGCookie,
  parseCookieString,
  parseKGCookieObject,
  setBrowserCookies,
  kgCookieUserId,
  kgCookieToken,
  kgCookieNickname,
  kgCookieAvatar,
  kgCookieDfid,
  kgCookieVipType,
  kgCookieLoginPwd,
  kgCookieVipToken,
  kgCookieHasVipSession,
  analyzeKGCookieSession,
} from './cookies.js';

const KG_UA_MOBILE = 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36';
const KG_UA_PC = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const KG_ANDROID_UA = 'Android15-1070-11083-46-0-DiscoveryDRADProtocol-wifi';
const KG_ANDROID_APPID = 1005;
const KG_ANDROID_CLIENTVER = 20489;
const KG_ANDROID_SIGN_SALT = 'OIlwieks28dk2k092lksi2UIkp';
const KG_PRODUCT_VIP_TYPE = { tvip: 6, vip: 6, svip: 33, qvip: 6, dvip: 6, mvip: 3 };
const KG_TRACKER_SECRET = '57ae12eb6890223e355ccfcb74edf70d1005';
const KG_TRACKER_HOSTS = [
  'https://trackercdn.kugou.com',
  'https://trackercdnbj.kugou.com',
  'http://trackercdn.kugou.com',
  'http://trackercdnbj.kugou.com',
];
let kgMidCache = '';

function md5(text) {
  return CryptoJS.MD5(String(text || '')).toString();
}

function signatureKGAndroidParams(params, data) {
  const paramsString = Object.keys(params)
    .sort()
    .map((key) => `${key}=${typeof params[key] === 'object' ? JSON.stringify(params[key]) : params[key]}`)
    .join('');
  return md5(`${KG_ANDROID_SIGN_SALT}${paramsString}${data || ''}${KG_ANDROID_SIGN_SALT}`);
}

async function kgFetchAndroidSigned(baseURL, urlPath, cookieHeader, extraParams) {
  extraParams = extraParams || {};
  const userId = kgCookieUserId(cookieHeader);
  const token = kgCookieToken(cookieHeader);
  if (!userId || !token) return null;
  const mid = await getKGMid(cookieHeader);
  const dfid = kgCookieDfid(cookieHeader) || '-';
  const clienttime = Math.floor(Date.now() / 1000);
  const params = Object.assign({
    dfid,
    mid,
    uuid: '-',
    appid: KG_ANDROID_APPID,
    clientver: KG_ANDROID_CLIENTVER,
    clienttime,
    token,
    userid: userId,
  }, extraParams);
  params.signature = signatureKGAndroidParams(params);
  const qs = Object.keys(params)
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
    .join('&');
  const url = `${String(baseURL || '').replace(/\/$/, '')}${urlPath.startsWith('/') ? urlPath : `/${urlPath}`}?${qs}`;
  return kgFetchJSON(url, {
    mobile: true,
    referer: 'https://www.kugou.com/',
    headers: {
      Cookie: cookieHeader || '',
      'User-Agent': KG_ANDROID_UA,
      dfid: String(dfid),
      clienttime: String(clienttime),
      mid: String(mid),
      'kg-rc': '1',
      'kg-thash': '5d816a0',
      'kg-rec': '1',
      'kg-rf': 'B9EDA08A64250DEFFBCADDEE00F8F25F',
    },
  });
}

function decodeCookieValue(value) {
  try {
    return decodeURIComponent(String(value || '').replace(/\+/g, '%20')).trim();
  } catch (_) {
    return String(value || '').trim();
  }
}

function normalizeKGCover(url, size) {
  url = String(url || '').trim();
  if (!url) return '';
  return url.replace(/\{size\}/gi, String(size || 240));
}

function normalizeKGDuration(value, fromSearch) {
  const n = Number(value) || 0;
  if (!n) return 0;
  if (fromSearch || n < 10000) return Math.round(n * 1000);
  return Math.round(n);
}

function stripKGHighlightHtml(value) {
  return String(value || '')
    .replace(/<\/?em>/gi, '')
    .replace(/<[^>]+>/g, '')
    .trim();
}

function extractKGFee(item) {
  item = item || {};
  const payType = Number(item.PayType ?? item.pay_type ?? 0);
  const privilege = Number(item.Privilege ?? item.privilege ?? 0);
  if (payType === 1 || payType === 2 || payType === 4) return 1;
  if ((privilege & 2) === 2) return 1;
  return 0;
}

function extractKGCover(item, size) {
  item = item || {};
  const trans = item.trans_param || item.TransParam || {};
  return normalizeKGCover(
    item.Image || item.img || item.album_img || item.album_sizable_cover || item.albumimg ||
    trans.union_cover || trans.unionCover || trans.album_img || trans.imgurl || '',
    size || 240,
  );
}

function mapKGSong(item, fromSearch) {
  item = item || {};
  const hash = String(item.FileHash || item.hash || item.HASH || '').trim().toLowerCase();
  const albumId = String(item.AlbumID || item.album_id || item.albumid || item.AlbumId || item.album_id || '').trim();
  const albumAudioId = String(item.MixSongID || item.ID || item.AlbumAudioID || item.album_audio_id || '').trim();
  const fee = extractKGFee(item);
  let rawName = stripKGHighlightHtml(item.SongName || item.songname || item.name || '');
  let name = rawName;
  let artist = stripKGHighlightHtml(item.SingerName || item.singername || item.author_name || item.singer || '');
  const filename = stripKGHighlightHtml(item.filename || item.FileName || '');
  if (!name && filename) {
    if (filename.includes(' - ')) {
      const parts = filename.split(' - ');
      if (!artist) artist = parts[0].trim();
      name = parts.slice(1).join(' - ').trim() || filename;
    } else {
      name = filename;
    }
  }
  if (!artist && rawName.includes(' - ')) {
    const parts = rawName.split(' - ');
    artist = parts[0].trim();
    name = parts.slice(1).join(' - ').trim() || rawName;
  }
  const singerId = String(item.SingerId || item.singerid || item.singer_id || item.SingerID || '').trim();
  return {
    provider: 'kg',
    source: 'kg',
    type: 'kg',
    id: hash,
    hash,
    albumId,
    albumAudioId,
    singerId,
    artistId: singerId,
    name,
    artist,
    album: stripKGHighlightHtml(item.AlbumName || item.album_name || item.album || item.album_name || ''),
    cover: extractKGCover(item, 240),
    duration: normalizeKGDuration(item.Duration || item.duration || item.timelength, fromSearch),
    fee,
    privilege: Number(item.Privilege ?? item.privilege ?? 0) || 0,
    payType: Number(item.PayType ?? item.pay_type ?? 0) || 0,
    playable: fee === 0,
  };
}

function mapKGPlaylist(item) {
  item = item || {};
  return {
    provider: 'kg',
    source: 'kg',
    type: 'playlist',
    id: String(item.specialid || item.special_id || item.id || ''),
    name: stripKGHighlightHtml(item.specialname || item.special_name || item.name || ''),
    cover: normalizeKGCover(item.imgurl || item.img || item.pic || '', 240),
    trackCount: Number(item.songcount || item.song_count || item.count || 0) || 0,
    creator: item.nickname || item.username || '酷狗音乐',
  };
}

async function kgFetchText(url, opts) {
  opts = opts || {};
  const resp = await fetch(url, {
    method: opts.method || 'GET',
    headers: Object.assign({
      'User-Agent': opts.mobile ? KG_UA_MOBILE : KG_UA_PC,
      Referer: opts.referer || 'https://www.kugou.com/',
      Accept: 'application/json, text/plain, */*',
    }, opts.headers || {}),
    body: opts.body,
  });
  return resp.text();
}

async function kgFetchJSON(url, opts) {
  const text = await kgFetchText(url, opts);
  const cleaned = String(text || '').replace(/<!--[\s\S]*?-->/g, '').trim();
  try {
    return JSON.parse(cleaned || text);
  } catch (_) {
    return null;
  }
}

function buildKGMid() {
  let out = '';
  for (let i = 0; i < 38; i++) out += Math.floor(Math.random() * 10);
  return out;
}

async function getKGMid(cookieHeader) {
  const obj = parseCookieString(cookieHeader || '');
  const fromCookie = String(obj.mid || obj.kg_mid || obj.KG_M_ID || '').replace(/\D/g, '');
  if (fromCookie.length >= 20) return fromCookie.slice(0, 38);
  if (kgMidCache) return kgMidCache;
  try {
    const stored = await chrome.storage.local.get(['kgMid']);
    if (stored && stored.kgMid) {
      kgMidCache = String(stored.kgMid);
      return kgMidCache;
    }
  } catch (_) {}
  kgMidCache = buildKGMid();
  try { await chrome.storage.local.set({ kgMid: kgMidCache }); } catch (_) {}
  return kgMidCache;
}

function buildKGTrackerKey(hash, mid, userId) {
  hash = String(hash || '').trim().toLowerCase();
  userId = String(userId || '0').replace(/\D/g, '') || '0';
  return md5(hash + KG_TRACKER_SECRET + mid + userId);
}

function parseKGPlayUrl(body) {
  if (!body) return '';
  const candidates = [
    body.url,
    body.backupUrl,
    body.backup_url,
    body.data && body.data.url,
    body.data && body.data.backupUrl,
    body.data && body.data.backup_url,
  ];
  for (const urls of candidates) {
    if (Array.isArray(urls)) {
      const hit = urls.find((item) => item && /^https?:\/\//i.test(item));
      if (hit) return hit;
    }
    if (typeof urls === 'string' && /^https?:\/\//i.test(urls)) return urls;
  }
  return '';
}

function pickPlayInfoUrl(playInfo) {
  if (!playInfo || playInfo.error) return '';
  if (playInfo.url && /^https?:\/\//i.test(playInfo.url)) return playInfo.url;
  const backup = playInfo.backup_url;
  if (Array.isArray(backup) && backup[0]) return backup[0];
  if (typeof backup === 'string' && backup) return backup;
  return '';
}

function isExpiredKGVipTime(value) {
  const ts = Date.parse(String(value || '').replace(/-/g, '/'));
  return Number.isFinite(ts) ? ts < Date.now() : false;
}

function parseKGVipFromData(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return { vipType: 0, isVip: false };
  const nestedRaw = data.vip || data.user_vip || data.userVip || data.music_vip || {};
  const nested = (nestedRaw && typeof nestedRaw === 'object' && !Array.isArray(nestedRaw)) ? nestedRaw : {};
  const vipEnd = data.vip_end_time || data.vipEndTime || nested.vip_end_time || data.expire_time || data.expireTime;
  let vipType = Number(
    data.vip_type || data.vipType || data.VIPType || data.VipType ||
    nested.vip_type || nested.vipType || nested.type || 0,
  ) || 0;
  const productType = String(data.product_type || nested.product_type || data.busi_type || nested.busi_type || '').toLowerCase();
  const isVipFlag = Number(data.is_vip ?? data.isVip ?? nested.is_vip ?? nested.isVip ?? data.isVipUser ?? -1);
  let isVip = !!(
    (vipType > 0 && (!vipEnd || !isExpiredKGVipTime(vipEnd))) ||
    isVipFlag === 1 ||
    Number(data.vip) === 1 ||
    Number(nested.vip) === 1 ||
    Number(data.MusicPack) === 1 ||
    Number(data.musicpack) === 1 ||
    Number(data.y_type) > 0 ||
    Number(data.music_vip) > 0 ||
    (productType && !/^(free|none|0|normal)$/.test(productType) && Number(data.is_vip) === 1) ||
    (vipEnd && !isExpiredKGVipTime(vipEnd)) ||
    (data.svip_end_time && !isExpiredKGVipTime(data.svip_end_time)) ||
    (data.musicvip_end_time && !isExpiredKGVipTime(data.musicvip_end_time)) ||
    (nested.vip_end_time && !isExpiredKGVipTime(nested.vip_end_time))
  );
  if (Number(data.is_vip) === 1 && data.vip_end_time && !isExpiredKGVipTime(data.vip_end_time)) {
    isVip = true;
    vipType = Math.max(vipType, KG_PRODUCT_VIP_TYPE[productType] || 6);
  }
  if (Number(data.m_type) > 0 && data.m_end_time && !isExpiredKGVipTime(data.m_end_time)) {
    isVip = true;
    vipType = Math.max(vipType, Number(data.m_type) || 6);
  }
  if (Number(data.su_vip) > 0 || (data.su_vip_end_time && !isExpiredKGVipTime(data.su_vip_end_time))) {
    isVip = true;
    vipType = Math.max(vipType, 33);
  }
  return { vipType: vipType || (isVip ? 6 : 0), isVip };
}

function pushKGVipQueueItem(queue, value) {
  if (!value) return;
  if (Array.isArray(value)) queue.push(...value);
  else queue.push(value);
}

function extractKGVipFromPayload(payload) {
  let best = parseKGVipFromData(payload);
  const queue = [];
  pushKGVipQueueItem(queue, payload);
  if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
    ['busi_vip', 'busiVip', 'vip_info', 'vipInfo', 'music_vip', 'svip', 'data', 'info', 'user_vip'].forEach((key) => {
      pushKGVipQueueItem(queue, payload[key]);
    });
    if (Array.isArray(payload.list)) queue.push(...payload.list);
    if (Array.isArray(payload.vip_list)) queue.push(...payload.vip_list);
  }
  queue.forEach((item) => {
    const hit = parseKGVipFromData(item);
    if (hit.isVip && (!best.isVip || hit.vipType >= best.vipType)) best = hit;
  });
  return best;
}

function resolveKGVipMeta(data) {
  if (!data || typeof data !== 'object') return { vipLabel: '', expireTime: '' };
  if (Number(data.m_type) > 0 && data.m_end_time && !isExpiredKGVipTime(data.m_end_time)) {
    return { vipLabel: '豪华VIP', expireTime: String(data.m_end_time) };
  }
  if (Number(data.su_vip) > 0 || (data.su_vip_end_time && !isExpiredKGVipTime(data.su_vip_end_time))) {
    return { vipLabel: '超级VIP', expireTime: String(data.su_vip_end_time || data.vip_end_time || '') };
  }
  const items = Array.isArray(data.busi_vip) ? data.busi_vip : (Array.isArray(data.busiVip) ? data.busiVip : []);
  let bestItem = null;
  items.forEach((item) => {
    if (!item || Number(item.is_vip) !== 1) return;
    if (item.vip_end_time && isExpiredKGVipTime(item.vip_end_time)) return;
    if (!bestItem || String(item.vip_end_time || '') > String(bestItem.vip_end_time || '')) bestItem = item;
  });
  if (bestItem) {
    const pt = String(bestItem.product_type || '').toLowerCase();
    const label = pt === 'svip' ? '超级VIP' : (pt === 'mvip' ? '音乐包' : '豪华VIP');
    return { vipLabel: label, expireTime: String(bestItem.vip_end_time || '') };
  }
  if (Number(data.vip_type) > 0 && data.vip_end_time && !isExpiredKGVipTime(data.vip_end_time)) {
    return { vipLabel: '豪华VIP', expireTime: String(data.vip_end_time) };
  }
  return { vipLabel: '', expireTime: '' };
}

async function fetchKGUserVipDetail(cookieHeader) {
  const busiTypes = ['music', 'concept', ''];
  let best = { vipType: 0, isVip: false, vipLabel: '', expireTime: '', detail: null };
  for (const busiType of busiTypes) {
    try {
      const extra = busiType ? { busi_type: busiType } : {};
      const body = await kgFetchAndroidSigned('https://kugouvip.kugou.com', '/v1/get_union_vip', cookieHeader, extra);
      if (!body || Number(body.status) !== 1) continue;
      const data = body.data || body;
      const vip = extractKGVipFromPayload(data);
      const meta = resolveKGVipMeta(data);
      const merged = mergeKGVipState(best, vip);
      best = {
        vipType: merged.vipType,
        isVip: merged.isVip,
        vipLabel: meta.vipLabel || best.vipLabel,
        expireTime: meta.expireTime || best.expireTime,
        detail: data,
      };
    } catch (_) {}
  }
  return best.isVip || best.detail ? best : null;
}

export async function getKGUserVipDetail(cookieHeader) {
  cookieHeader = cookieHeader || await getKGCookie();
  const userId = kgCookieUserId(cookieHeader);
  const token = kgCookieToken(cookieHeader);
  if (!userId || !token) {
    return { provider: 'kg', loggedIn: false, error: 'NOT_LOGGED_IN', message: '未登录，无法查询 VIP 详情' };
  }
  const detail = await fetchKGUserVipDetail(cookieHeader);
  if (!detail) {
    return { provider: 'kg', loggedIn: true, userId, isVip: false, vipType: 0, error: 'VIP_DETAIL_EMPTY' };
  }
  return {
    provider: 'kg',
    loggedIn: true,
    userId,
    isVip: detail.isVip,
    vipType: detail.vipType,
    vipLabel: detail.vipLabel || (detail.isVip ? 'VIP' : '无VIP'),
    expireTime: detail.expireTime || '',
    detail: detail.detail,
  };
}

function mergeKGVipState(base, extra) {
  base = base || { vipType: 0, isVip: false };
  extra = extra || { vipType: 0, isVip: false };
  const vipType = Math.max(Number(base.vipType) || 0, Number(extra.vipType) || 0);
  const isVip = !!(base.isVip || extra.isVip || vipType > 0);
  return { vipType: vipType || (isVip ? 6 : 0), isVip };
}

function resolveKGTrackerVipType(cookieHeader, loginVipType) {
  const fromCookie = kgCookieVipType(cookieHeader);
  if (fromCookie > 0) return String(fromCookie);
  if (Number(loginVipType) > 0) return String(loginVipType);
  if (kgCookieHasVipSession(cookieHeader)) return '6';
  if (kgCookieToken(cookieHeader)) return '6';
  return '0';
}

function buildKGTrackerVipTypeCandidates(cookieHeader, loginVipType) {
  return [...new Set([
    resolveKGTrackerVipType(cookieHeader, loginVipType),
    String(kgCookieVipType(cookieHeader) || ''),
    kgCookieHasVipSession(cookieHeader) ? '6' : '',
    kgCookieToken(cookieHeader) ? '6' : '',
    '6', '11', '33', '3',
  ].filter(Boolean))];
}

async function fetchKGUserProfile(cookieHeader) {
  const userId = kgCookieUserId(cookieHeader);
  const token = kgCookieToken(cookieHeader);
  if (!userId || !token) return null;
  const mid = await getKGMid(cookieHeader);
  const u = new URL('http://userinfo.user.kugou.com/v2/get_user_info');
  u.searchParams.set('appid', '1005');
  u.searchParams.set('clientver', '9108');
  u.searchParams.set('mid', mid);
  u.searchParams.set('userid', userId);
  u.searchParams.set('token', token);
  u.searchParams.set('dfid', kgCookieDfid(cookieHeader));
  u.searchParams.set('plat', '0');
  try {
    let body = await kgFetchJSON(u.toString(), {
      mobile: true,
      referer: 'https://www.kugou.com/',
      headers: { Cookie: cookieHeader || '' },
    });
    if (!body || Number(body.status) !== 1) {
      const httpsUrl = u.toString().replace(/^http:/, 'https:');
      body = await kgFetchJSON(httpsUrl, {
        mobile: true,
        referer: 'https://www.kugou.com/',
        headers: { Cookie: cookieHeader || '' },
      });
    }
    if (!body || Number(body.status) !== 1) return null;
    const data = body.data || body.info;
    if (!data || typeof data !== 'object') return null;
    const vip = extractKGVipFromPayload(data);
    return {
      nickname: stripKGHighlightHtml(data.nickname || data.nick_name || data.username || data.user_name || ''),
      avatar: normalizeKGCover(data.pic || data.Pic || data.user_pic || data.avatar || data.userpic || '', 180),
      vipType: vip.vipType,
      isVip: vip.isVip,
    };
  } catch (_) {
    return null;
  }
}

async function fetchKGUnionVip(cookieHeader) {
  const userId = kgCookieUserId(cookieHeader);
  const token = kgCookieToken(cookieHeader);
  const loginPwd = kgCookieLoginPwd(cookieHeader);
  if (!userId || !token) return null;
  const mid = await getKGMid(cookieHeader);
  const dfid = kgCookieDfid(cookieHeader);
  const common = `appid=1005&clientver=9108&mid=${encodeURIComponent(mid)}&userid=${encodeURIComponent(userId)}&token=${encodeURIComponent(token)}&dfid=${encodeURIComponent(dfid)}`;
  const pwdPart = loginPwd ? `&pwd=${encodeURIComponent(loginPwd)}&KugooPwd=${encodeURIComponent(loginPwd)}` : '';
  const urls = [
    `http://mobileservice.kugou.com/api/v5/vip_info?${common}${pwdPart}&format=json`,
    `http://mobileservice.kugou.com/api/v5/vip_status?${common}${pwdPart}`,
    `https://kugouvip.kugou.com/v1/get_union_vip?busi_type=concept&${common}`,
    `https://kugouvip.kugou.com/v1/get_union_vip?busi_type=music&${common}`,
    `https://kugouvip.kugou.com/v1/get_union_vip?${common}`,
    `http://vip.kugou.com/recharge/getUserVip?kugouid=${encodeURIComponent(userId)}&clienttoken=${encodeURIComponent(token)}&appid=1005${loginPwd ? `&KugooPwd=${encodeURIComponent(loginPwd)}` : ''}`,
    `http://mobilecdn.kugou.com/api/v3/user/vip?userid=${encodeURIComponent(userId)}&token=${encodeURIComponent(token)}&appid=1005&mid=${encodeURIComponent(mid)}${loginPwd ? `&KugooPwd=${encodeURIComponent(loginPwd)}` : ''}`,
  ];
  let best = { vipType: 0, isVip: false };
  for (const url of urls) {
    try {
      const body = await kgFetchJSON(url, {
        mobile: true,
        referer: 'https://www.kugou.com/',
        headers: { Cookie: cookieHeader || '' },
      });
      if (!body) continue;
      const vip = extractKGVipFromPayload(body.data || body.info || body);
      if (vip.isVip) best = mergeKGVipState(best, vip);
    } catch (_) {}
  }
  return best.isVip ? best : null;
}

async function fetchKGMobileVipInfo(cookieHeader) {
  const userId = kgCookieUserId(cookieHeader);
  const token = kgCookieToken(cookieHeader);
  if (!userId || !token) return null;
  const mid = await getKGMid(cookieHeader);
  const dfid = kgCookieDfid(cookieHeader);
  const common = `userid=${encodeURIComponent(userId)}&token=${encodeURIComponent(token)}&appid=1005&clientver=9108&mid=${encodeURIComponent(mid)}&dfid=${encodeURIComponent(dfid)}`;
  const urls = [
    `http://mobilecdn.kugou.com/api/v3/user/vipinfo?${common}`,
    `http://mobileservice.kugou.com/api/v3/user/vip?${common}`,
    `http://mobileservice.kugou.com/api/v5/user/vip?${common}`,
  ];
  let best = { vipType: 0, isVip: false };
  for (const url of urls) {
    try {
      const body = await kgFetchJSON(url, {
        mobile: true,
        referer: 'https://www.kugou.com/',
        headers: { Cookie: cookieHeader || '' },
      });
      if (!body) continue;
      const vip = extractKGVipFromPayload(body.data || body.info || body);
      if (vip.isVip) best = mergeKGVipState(best, vip);
    } catch (_) {}
  }
  return best.isVip ? best : null;
}


export async function getKGLoginStatus(cookieHeader) {
  cookieHeader = cookieHeader || await getKGCookie();
  const userId = kgCookieUserId(cookieHeader);
  const token = kgCookieToken(cookieHeader);
  const loggedIn = !!(userId && token);
  let nickname = kgCookieNickname(cookieHeader);
  let avatar = kgCookieAvatar(cookieHeader);
  let vipType = kgCookieVipType(cookieHeader);
  let isVip = kgCookieHasVipSession(cookieHeader);
  let vipLabel = isVip ? 'VIP' : '无VIP';
  let expireTime = '';
  if (loggedIn) {
    const vipDetail = await fetchKGUserVipDetail(cookieHeader);
    if (vipDetail) {
      ({ vipType, isVip } = mergeKGVipState({ vipType, isVip }, vipDetail));
      if (vipDetail.vipLabel) vipLabel = vipDetail.vipLabel;
      if (vipDetail.expireTime) expireTime = vipDetail.expireTime;
    }
    const profile = await fetchKGUserProfile(cookieHeader);
    if (profile) {
      if (profile.nickname) nickname = profile.nickname;
      if (profile.avatar) avatar = profile.avatar;
      ({ vipType, isVip } = mergeKGVipState({ vipType, isVip }, profile));
    }
    const union = await fetchKGUnionVip(cookieHeader);
    if (union) ({ vipType, isVip } = mergeKGVipState({ vipType, isVip }, union));
    const mobileVip = await fetchKGMobileVipInfo(cookieHeader);
    if (mobileVip) ({ vipType, isVip } = mergeKGVipState({ vipType, isVip }, mobileVip));
    if (!isVip && kgCookieHasVipSession(cookieHeader)) {
      vipType = vipType || 6;
      isVip = true;
      vipLabel = vipLabel === '无VIP' ? 'VIP' : vipLabel;
    }
    if (isVip && vipLabel === '无VIP') vipLabel = 'VIP';
  }
  return {
    provider: 'kg',
    loggedIn,
    hasCookie: !!cookieHeader,
    userId,
    nickname: nickname || (loggedIn ? `酷狗 ${userId}` : '酷狗音乐'),
    avatar,
    vipType,
    isVip,
    vipLabel,
    expireTime,
    session: analyzeKGCookieSession(cookieHeader),
    hasKuGooSession: !!(parseKGCookieObject(cookieHeader).KugooID || parseKGCookieObject(cookieHeader).KugooID),
    message: !loggedIn
      ? '未检测到酷狗登录 Cookie（需要 KuGoo 或 userid+token）。你目前可能只有统计/路由 Cookie，请在 www.kugou.com 用手机号或微信完整登录。'
      : (!isVip ? '已登录（KuGoo 有效）。PC 站 KuGoo 通常不含 VIP 字段，会员状态由接口查询；若 App 有会员但这里仍显示普通账号，请在酷狗 App 内确认会员未过期。' : ''),
  };
}

export async function handleKGSearch(keywords, limit, cookieHeader) {
  keywords = String(keywords || '').trim();
  limit = Math.max(4, Math.min(30, Number(limit) || 16));
  if (!keywords) return [];
  const u = new URL('https://songsearch.kugou.com/song_search_v2');
  u.searchParams.set('keyword', keywords);
  u.searchParams.set('platform', 'WebFilter');
  u.searchParams.set('format', 'json');
  u.searchParams.set('page', '1');
  u.searchParams.set('pagesize', String(limit));
  u.searchParams.set('userid', '-1');
  u.searchParams.set('tag', 'em');
  u.searchParams.set('filter', '2');
  u.searchParams.set('iscorrection', '1');
  u.searchParams.set('privilege_filter', '0');
  u.searchParams.set('_', String(Date.now()));
  let body = await kgFetchJSON(u.toString(), { mobile: true, headers: { Cookie: cookieHeader || '' } });
  if (!body || !body.data) {
    body = await kgFetchJSON(u.toString(), { mobile: true });
  }
  const list = (body && body.data && body.data.lists) || [];
  return list.map((item) => mapKGSong(item, true)).filter((s) => s.hash && s.name);
}

async function fetchKGPlayInfo(hash, albumAudioId, cookieHeader) {
  const u = new URL('https://m.kugou.com/app/i/getSongInfo.php');
  u.searchParams.set('cmd', 'playInfo');
  u.searchParams.set('hash', String(hash || '').trim());
  if (albumAudioId) u.searchParams.set('album_audio_id', String(albumAudioId));
  return kgFetchJSON(u.toString(), {
    mobile: true,
    referer: 'https://m.kugou.com/',
    headers: { Cookie: cookieHeader || '' },
  });
}

async function fetchKGTrackerUrl(hash, albumId, albumAudioId, cookieHeader, loginVipType) {
  hash = String(hash || '').trim().toLowerCase();
  if (!hash) return { url: '', status: 0, blocked: false };
  const userId = kgCookieUserId(cookieHeader) || '0';
  const token = kgCookieToken(cookieHeader) || '';
  const mid = await getKGMid(cookieHeader);
  const key = buildKGTrackerKey(hash, mid, userId);
  const audioId = String(albumAudioId || '0');
  const dfid = kgCookieDfid(cookieHeader);
  const vipTypeCandidates = buildKGTrackerVipTypeCandidates(cookieHeader, loginVipType);
  const vipToken = kgCookieVipToken(cookieHeader);
  let lastStatus = 0;
  for (const host of KG_TRACKER_HOSTS) {
    for (const vipType of vipTypeCandidates) {
      const u = new URL(`${host}/i/v2/`);
      u.searchParams.set('cmd', '26');
      u.searchParams.set('key', key);
      u.searchParams.set('hash', hash);
      u.searchParams.set('behavior', 'play');
      u.searchParams.set('mid', mid);
      u.searchParams.set('dfid', dfid);
      u.searchParams.set('appid', '1005');
      u.searchParams.set('userid', userId);
      u.searchParams.set('version', '9108');
      u.searchParams.set('vipType', vipType);
      u.searchParams.set('token', token);
      if (vipToken) u.searchParams.set('vip_token', vipToken);
      u.searchParams.set('album_id', albumId || '0');
      u.searchParams.set('album_audio_id', audioId);
      u.searchParams.set('area_code', '1');
      u.searchParams.set('pid', '2');
      u.searchParams.set('pidversion', '3001');
      u.searchParams.set('with_res_tag', '1');
      const body = await kgFetchJSON(u.toString(), {
        mobile: true,
        referer: 'https://www.kugou.com/',
        headers: { Cookie: cookieHeader || '' },
      });
      const url = parseKGPlayUrl(body);
      if (url) return { url, status: Number(body && body.status) || 1, blocked: false };
      lastStatus = Number(body && body.status) || lastStatus;
    }
  }
  return { url: '', status: lastStatus, blocked: lastStatus === 2 };
}

async function fetchKGPlayGetData(hash, albumId, albumAudioId, cookieHeader, loginVipType) {
  hash = String(hash || '').trim().toLowerCase();
  if (!hash) return '';
  const userId = kgCookieUserId(cookieHeader) || '0';
  const token = kgCookieToken(cookieHeader) || '';
  const mid = await getKGMid(cookieHeader);
  const dfid = kgCookieDfid(cookieHeader);
  const u = new URL('https://wwwapi.kugou.com/yy/index.php');
  u.searchParams.set('r', 'play/getdata');
  u.searchParams.set('hash', hash);
  u.searchParams.set('album_id', albumId || '0');
  if (albumAudioId) u.searchParams.set('album_audio_id', String(albumAudioId));
  u.searchParams.set('mid', mid);
  u.searchParams.set('dfid', dfid);
  u.searchParams.set('appid', '1005');
  u.searchParams.set('clientver', '9108');
  u.searchParams.set('userid', userId);
  u.searchParams.set('token', token);
  u.searchParams.set('vipType', resolveKGTrackerVipType(cookieHeader, loginVipType));
  u.searchParams.set('plat', '0');
  try {
    const body = await kgFetchJSON(u.toString(), {
      referer: 'https://www.kugou.com/',
      headers: { Cookie: cookieHeader || '' },
    });
    const data = body && body.data;
    const url = data && (data.play_url || data.play_backup_url || data.playUrl || data.url);
    if (typeof url === 'string' && url) return url;
    if (Array.isArray(url) && url[0]) return url[0];
  } catch (_) {}
  return '';
}

function normalizePlayUrl(url) {
  url = String(url || '').trim();
  if (!url) return '';
  if (/^https?:\/\//i.test(url)) return url;
  if (url.startsWith('//')) return 'http:' + url;
  if (url.startsWith('/')) return 'http://fs.open.kugou.com' + url;
  return 'http://fs.open.kugou.com/' + url.replace(/^\/+/, '');
}

export async function handleKGSongUrl(hash, albumId, albumAudioId, quality, cookieHeader) {
  hash = String(hash || '').trim().toLowerCase();
  albumId = String(albumId || '').trim();
  albumAudioId = String(albumAudioId || '').trim();
  if (!hash) {
    return { provider: 'kg', url: '', playable: false, error: 'MISSING_HASH', message: 'Missing Kugou song hash' };
  }
  cookieHeader = cookieHeader || await getKGCookie();
  const login = await getKGLoginStatus(cookieHeader);
  const successPayload = (url, source) => ({
    provider: 'kg',
    url: normalizePlayUrl(url),
    playable: true,
    loggedIn: login.loggedIn,
    isVip: login.isVip,
    vipType: login.vipType,
    vipLabel: login.vipLabel,
    level: quality || 'exhigh',
    source,
  });
  let trackerResult = { url: '', status: 0, blocked: false };
  try {
    trackerResult = await fetchKGTrackerUrl(hash, albumId, albumAudioId, cookieHeader, login.vipType);
    if (trackerResult.url) return successPayload(trackerResult.url, 'tracker');
  } catch (_) {}
  try {
    const playInfo = await fetchKGPlayInfo(hash, albumAudioId, cookieHeader);
    const fromInfo = pickPlayInfoUrl(playInfo);
    if (fromInfo) return successPayload(fromInfo, 'playInfo');
  } catch (_) {}
  try {
    const fromGetData = await fetchKGPlayGetData(hash, albumId, albumAudioId, cookieHeader, login.vipType);
    if (fromGetData) return successPayload(fromGetData, 'getdata');
  } catch (_) {}
  const blocked = trackerResult.blocked || trackerResult.status === 2;
  const likelyVipSong = blocked || trackerResult.status === 2;
  return {
    provider: 'kg',
    url: '',
    playable: false,
    loggedIn: login.loggedIn,
    isVip: login.isVip,
    vipType: login.vipType,
    vipLabel: login.vipLabel,
    error: !login.loggedIn ? 'LOGIN_REQUIRED' : (likelyVipSong && !login.isVip ? 'VIP_REQUIRED' : 'URL_UNAVAILABLE'),
    reason: !login.loggedIn ? 'login_required' : (likelyVipSong ? 'vip_required' : 'url_unavailable'),
    message: !login.loggedIn
      ? '酷狗会员歌曲需要登录后播放'
      : (likelyVipSong && !login.isVip
        ? '酷狗会员歌曲需要开通酷狗 VIP，或在 kugou.com 重新登录后再试'
        : '酷狗未返回播放地址，请确认账号会员有效并在官网重新登录'),
    trackerStatus: trackerResult.status || 0,
  };
}

function decodeKGLyricContent(content) {
  content = String(content || '').trim();
  if (!content) return '';
  try {
    if (!content.includes('[') && /^[A-Za-z0-9+/=\s]+$/.test(content)) {
      const bin = atob(content.replace(/\s/g, ''));
      const decoded = decodeURIComponent(escape(bin));
      if (decoded && (decoded.includes('[') || /[\u4e00-\u9fa5]/.test(decoded))) return decoded;
    }
  } catch (_) {}
  return content;
}

async function fetchKGBasicLrc(hash) {
  if (!hash) return '';
  try {
    const text = await kgFetchText(`http://m.kugou.com/krc/${encodeURIComponent(hash)}.lrc`, {
      mobile: true,
      referer: 'https://m.kugou.com/',
    });
    return String(text || '').trim();
  } catch (_) {
    return '';
  }
}

export async function handleKGLyric(hash, albumId, duration) {
  hash = String(hash || '').trim();
  albumId = String(albumId || '').trim();
  if (!hash) return { provider: 'kg', lyric: '', error: 'MISSING_HASH' };
  let lyric = await fetchKGBasicLrc(hash);
  if (lyric) return { provider: 'kg', lyric, source: 'basic' };
  try {
    const u = new URL('https://krcs.kugou.com/search');
    u.searchParams.set('ver', '1');
    u.searchParams.set('man', 'yes');
    u.searchParams.set('client', 'mobi');
    u.searchParams.set('keyword', hash);
    u.searchParams.set('hash', hash);
    if (albumId) u.searchParams.set('album_audio_id', albumId);
    if (duration) u.searchParams.set('duration', String(Math.max(1, Math.round(Number(duration) / 1000))));
    const search = await kgFetchJSON(u.toString(), { mobile: true, referer: 'https://www.kugou.com/' });
    const candidate = (search && search.candidates && search.candidates[0]) || null;
    if (candidate && candidate.id && candidate.accesskey) {
      const dl = new URL('http://lyrics.kugou.com/download');
      dl.searchParams.set('ver', '1');
      dl.searchParams.set('client', 'pc');
      dl.searchParams.set('id', String(candidate.id));
      dl.searchParams.set('accesskey', String(candidate.accesskey));
      dl.searchParams.set('fmt', 'lrc');
      dl.searchParams.set('charset', 'utf8');
      const body = await kgFetchJSON(dl.toString(), { referer: 'https://www.kugou.com/' });
      lyric = decodeKGLyricContent(body && (body.content || body.data && body.data.content));
      if (lyric) return { provider: 'kg', lyric, source: 'krc' };
    }
  } catch (_) {}
  return { provider: 'kg', lyric: '' };
}

export async function handleKGUserPlaylists(cookieHeader) {
  cookieHeader = cookieHeader || await getKGCookie();
  const login = await getKGLoginStatus(cookieHeader);
  if (!login.loggedIn) return { provider: 'kg', loggedIn: false, playlists: [] };
  const u = new URL('http://m.kugou.com/plist/index');
  u.searchParams.set('op', 'getMyPlist');
  u.searchParams.set('token', kgCookieToken(cookieHeader));
  u.searchParams.set('t', String(Date.now()));
  const body = await kgFetchJSON(u.toString(), {
    mobile: true,
    referer: 'http://m.kugou.com/',
    headers: { Cookie: cookieHeader },
  });
  const list = (body && (body.lists || body.data && body.data.lists)) || [];
  const playlists = list.map(mapKGPlaylist).filter((pl) => pl.id);
  return { provider: 'kg', loggedIn: true, userId: login.userId, playlists };
}

export async function handleKGPlaylistTracks(id, cookieHeader) {
  id = String(id || '').trim();
  if (!id) return { provider: 'kg', error: 'Missing playlist id', tracks: [] };
  cookieHeader = cookieHeader || await getKGCookie();
  const login = await getKGLoginStatus(cookieHeader);
  const pageSize = 200;
  let page = 1;
  let total = Infinity;
  const tracks = [];
  while (tracks.length < total && page <= 20) {
    const u = new URL('http://mobilecdn.kugou.com/api/v3/special/song');
    u.searchParams.set('specialid', id);
    u.searchParams.set('page', String(page));
    u.searchParams.set('pagesize', String(pageSize));
    u.searchParams.set('version', '9108');
    u.searchParams.set('area_code', '1');
    const body = await kgFetchJSON(u.toString(), {
      mobile: true,
      referer: 'https://www.kugou.com/',
      headers: { Cookie: cookieHeader || '' },
    });
    const info = (body && body.data && body.data.info) || (body && body.info) || [];
    total = Number((body && body.data && body.data.total) || body.total || info.length) || info.length;
    info.forEach((item) => {
      const song = mapKGSong(item, false);
      if (song.hash) tracks.push(song);
    });
    if (!info.length) break;
    page += 1;
  }
  const playlist = { id, provider: 'kg', trackCount: tracks.length };
  return { provider: 'kg', loggedIn: login.loggedIn, playlist, tracks };
}

export function normalizeKGCookieInput(raw) {
  return String(raw || '').trim();
}

export function validateKGCookie(raw) {
  const obj = parseKGCookieObject(normalizeKGCookieInput(raw));
  const userId = obj.userid || obj.KugooID || obj.kugouid || '';
  const token = obj.token || obj.KToken || obj.kg_token || obj.t || '';
  return !!(String(userId).trim() && String(token).trim());
}

function normalizeKGArtistName(name) {
  return String(name || '').replace(/<[^>]+>/g, '').trim().toLowerCase();
}

async function searchKGSingerId(name) {
  name = String(name || '').trim();
  if (!name) return { singerId: '', singerName: '' };
  const u = new URL('http://mobilecdn.kugou.com/api/v3/search/singer');
  u.searchParams.set('keyword', name);
  u.searchParams.set('page', '1');
  u.searchParams.set('pagesize', '8');
  u.searchParams.set('version', '9108');
  u.searchParams.set('plat', '0');
  u.searchParams.set('with_res_tag', '1');
  const body = await kgFetchJSON(u.toString(), { mobile: true, referer: 'https://www.kugou.com/' });
  const list = (body && body.data && body.data.info) || (body && body.info) || [];
  const target = normalizeKGArtistName(name);
  const matched = list.find((item) => normalizeKGArtistName(item.singername || item.author_name || item.name) === target)
    || list.find((item) => {
      const candidate = normalizeKGArtistName(item.singername || item.author_name || item.name);
      return candidate && (candidate.includes(target) || target.includes(candidate));
    })
    || list[0];
  if (!matched) return { singerId: '', singerName: name };
  return {
    singerId: String(matched.singerid || matched.singer_id || matched.id || '').trim(),
    singerName: matched.singername || matched.author_name || matched.name || name,
  };
}

export async function handleKGArtistDetail(id, name, limit) {
  limit = Math.max(10, Math.min(80, Number(limit) || 36));
  let singerId = String(id || '').trim();
  let singerName = String(name || '').trim();
  if (!singerId && singerName) {
    const found = await searchKGSingerId(singerName);
    singerId = found.singerId;
    singerName = found.singerName || singerName;
  }
  if (!singerId) {
    return { provider: 'kg', error: 'MISSING_SINGER_ID', message: '缺少酷狗歌手 ID', artist: null, songs: [] };
  }
  let info = {};
  try {
    const infoBody = await kgFetchJSON(
      `http://mobilecdn.kugou.com/api/v3/singer/info?singerid=${encodeURIComponent(singerId)}&with_res_tag=1`,
      { mobile: true, referer: 'https://www.kugou.com/' },
    );
    info = (infoBody && infoBody.data) || infoBody || {};
  } catch (_) {}
  const songsUrl = new URL('http://mobilecdn.kugou.com/api/v3/singer/song');
  songsUrl.searchParams.set('singerid', singerId);
  songsUrl.searchParams.set('page', '1');
  songsUrl.searchParams.set('pagesize', String(limit));
  songsUrl.searchParams.set('sorttype', '2');
  songsUrl.searchParams.set('plat', '0');
  songsUrl.searchParams.set('version', '9108');
  songsUrl.searchParams.set('area_code', '1');
  songsUrl.searchParams.set('with_res_tag', '1');
  let rawSongs = [];
  try {
    const songsBody = await kgFetchJSON(songsUrl.toString(), { mobile: true, referer: 'https://www.kugou.com/' });
    rawSongs = (songsBody && songsBody.data && songsBody.data.info) || (songsBody && songsBody.info) || [];
  } catch (_) {}
  return {
    provider: 'kg',
    artist: {
      provider: 'kg',
      id: singerId,
      name: info.singername || info.author_name || singerName || '',
      avatar: normalizeKGCover(info.imgurl || info.singerHead || info.pic || info.avatar || '', 240),
      briefDesc: info.intro || info.description || '',
    },
    songs: rawSongs.map((item) => mapKGSong(item, false)).filter((song) => song.hash && song.name),
  };
}

function parseKGCommentTime(value) {
  const text = String(value || '').trim();
  if (!text) return 0;
  const parsed = Date.parse(text.replace(/-/g, '/'));
  return Number.isFinite(parsed) ? parsed : 0;
}

export async function handleKGSongComments(hash, albumAudioId, limit, page) {
  hash = String(hash || '').trim().toLowerCase();
  albumAudioId = String(albumAudioId || '').trim();
  limit = Math.max(1, Math.min(40, Number(limit) || 20));
  page = Math.max(1, Number(page) || 1);
  if (!hash) {
    return { provider: 'kg', error: 'Missing song hash', comments: [] };
  }
  const u = new URL('http://m.comment.service.kugou.com/index.php');
  u.searchParams.set('r', 'commentsv2/getCommentWithLike');
  u.searchParams.set('extdata', hash);
  u.searchParams.set('p', String(page));
  u.searchParams.set('pagesize', String(limit));
  u.searchParams.set('code', 'fc4be23b4e972707f36b8a828a93ba8a');
  u.searchParams.set('clientver', '8983');
  if (albumAudioId) u.searchParams.set('mixsongid', albumAudioId);
  try {
    const body = await kgFetchJSON(u.toString(), { referer: 'https://www.kugou.com/' });
    const raw = (body && (body.list || body.comments)) || [];
    const comments = (Array.isArray(raw) ? raw : [])
      .map((item) => ({
        id: item.id || item.cmtid || item.comment_id || '',
        content: stripKGHighlightHtml(item.content || item.msg || ''),
        likedCount: Number((item.like && (item.like.likenum || item.like.count)) || item.like_count || 0) || 0,
        time: parseKGCommentTime(item.addtime || item.add_time || item.time),
        user: {
          id: item.user_id || (item.udetail && item.udetail.user_id) || '',
          nickname: stripKGHighlightHtml(item.user_name || item.nickname || item.username || '酷狗用户'),
          avatar: item.user_pic || item.user_avatar || (item.udetail && item.udetail.user_pic) || '',
        },
      }))
      .filter((item) => item.content);
    return {
      provider: 'kg',
      hash,
      albumAudioId,
      total: Number((body && (body.combine_count || body.count)) || 0) || comments.length,
      comments,
    };
  } catch (err) {
    return { provider: 'kg', error: err.message || 'KG_COMMENTS_FAILED', comments: [] };
  }
}

export async function handleKGLoginCookie(raw) {
  const normalized = normalizeKGCookieInput(raw);
  if (!validateKGCookie(normalized)) {
    return {
      provider: 'kg',
      loggedIn: false,
      error: 'INVALID_KG_COOKIE',
      message: '酷狗 cookie 缺少 userid 或 token',
    };
  }
  await setBrowserCookies('https://www.kugou.com/', normalized);
  await setBrowserCookies('https://m.kugou.com/', normalized);
  const cookieHeader = await getKGCookie();
  const info = await getKGLoginStatus(cookieHeader);
  return { ...info, saved: info.loggedIn, hasCookie: info.loggedIn };
}
