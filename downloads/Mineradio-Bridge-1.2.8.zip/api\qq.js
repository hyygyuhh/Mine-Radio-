import {
  getQQCookie,
  parseCookieString,
  qqCookieAvatar,
  qqCookieMusicKey,
  qqCookieNickname,
  qqCookiePlaybackKey,
  qqCookieUin,
} from './cookies.js';
import { UA } from './weapi.js';

const QQ_MUSICU_URL = 'https://u.y.qq.com/cgi-bin/musicu.fcg';
const QQ_SMARTBOX_URL = 'https://c.y.qq.com/splcloud/fcgi-bin/smartbox_new.fcg';

function normalizeQualityPreference(value) {
  const raw = String(value || '').toLowerCase().trim();
  if (['jymaster', 'master', 'studio', 'svip', 'highest'].includes(raw)) return 'jymaster';
  if (['hires', 'hi-res', 'highres', 'zhenyin', 'spatial'].includes(raw)) return 'hires';
  if (['lossless', 'flac', 'sq'].includes(raw)) return 'lossless';
  if (['exhigh', 'high', '320', '320k', 'hq'].includes(raw)) return 'exhigh';
  if (['standard', 'normal', '128', '128k', 'std'].includes(raw)) return 'standard';
  return 'hires';
}

const QQ_QUALITY_CANDIDATE_TEMPLATES = [
  { prefix: 'RS01', ext: '.flac', level: 'hires', label: 'Hi-Res FLAC' },
  { prefix: 'F000', ext: '.flac', level: 'lossless', label: '无损 FLAC' },
  { prefix: 'M800', ext: '.mp3', level: 'exhigh', label: '320k MP3' },
  { prefix: 'M500', ext: '.mp3', level: 'standard', label: '128k MP3' },
  { prefix: 'C400', ext: '.m4a', level: 'aac', label: 'AAC/M4A' },
];

function qualityCandidatesFrom(target, candidates) {
  target = normalizeQualityPreference(target);
  let start = candidates.findIndex((item) => item.level === target);
  if (start < 0) start = 0;
  return candidates.slice(start);
}

function playbackRestriction(provider, category, message, action, extra) {
  return Object.assign({ provider, category, message, action: action || 'none' }, extra || {});
}

function classifyQQPlaybackRestriction(info, session) {
  const hasSession = typeof session === 'object' ? !!session.hasSession : !!session;
  const hasPlaybackKey = typeof session === 'object' ? !!session.hasPlaybackKey : hasSession;
  const rawMsg = String((info && (info.msg || info.tips || info.errmsg || info.message)) || '').trim();
  const code = Number((info && (info.result || info.code || info.errtype)) || 0);
  const lower = rawMsg.toLowerCase();
  if (!hasSession) {
    return playbackRestriction('qq', 'login_required', 'QQ 音乐需要登录或授权后才能获取播放地址', 'login', { code, rawMessage: rawMsg });
  }
  if (!hasPlaybackKey && code === 104003) {
    return playbackRestriction('qq', 'login_required', 'QQ 音乐当前只拿到了网页登录状态，还缺少播放授权，请重新打开 y.qq.com 完成登录', 'login', { code, rawMessage: rawMsg, missingPlaybackKey: true });
  }
  if (code === 104003) {
    return playbackRestriction('qq', 'copyright_unavailable', 'QQ 音乐没有给当前版本返回播放地址，通常是版权、会员或官方版本限制', 'switch_source', { code, rawMessage: rawMsg });
  }
  if (/vip|会员|付费|购买|数字专辑|专辑|pay/.test(lower + rawMsg)) {
    return playbackRestriction('qq', 'vip_required', 'QQ 音乐歌曲需要会员、购买或数字专辑权限', 'upgrade', { code, rawMessage: rawMsg });
  }
  if (code && code !== 0) {
    return playbackRestriction('qq', 'copyright_unavailable', rawMsg || 'QQ 音乐版权暂不可播或仅官方客户端可播', 'switch_source', { code, rawMessage: rawMsg });
  }
  return playbackRestriction('qq', 'url_unavailable', 'QQ 音乐没有返回播放地址，可能受版权、会员或官方客户端限制', 'switch_source', { code, rawMessage: rawMsg });
}

function parseJSONText(text) {
  const raw = String(text || '').trim();
  return JSON.parse(raw.replace(/^callback\(([\s\S]*)\);?$/, '$1'));
}

function decodeHtmlEntities(text) {
  return String(text || '')
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(parseInt(dec, 10)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&nbsp;/g, ' ');
}

function decodeQQLyricText(text) {
  let raw = decodeHtmlEntities(String(text || '').trim());
  if (!raw) return '';
  try {
    if (!raw.includes('[') && /^[A-Za-z0-9+/=]+$/.test(raw.replace(/\s+/g, ''))) {
      const bin = atob(raw.replace(/\s+/g, ''));
      const decoded = decodeURIComponent(escape(bin));
      if (decoded && (decoded.includes('[') || /[\u4e00-\u9fa5]/.test(decoded))) raw = decoded;
    }
  } catch (_) {}
  return decodeHtmlEntities(raw).replace(/\r\n/g, '\n').trim();
}

function qqAlbumCover(albumMid, size) {
  if (!albumMid) return '';
  const px = size || 300;
  return `https://y.qq.com/music/photo_new/T002R${px}x${px}M000${albumMid}.jpg?max_age=2592000`;
}

function qqSingerAvatar(singerMid, size) {
  if (!singerMid) return '';
  const px = size || 300;
  return `https://y.qq.com/music/photo_new/T001R${px}x${px}M000${singerMid}.jpg?max_age=2592000`;
}

function mapQQArtists(raw) {
  return (raw || [])
    .map((a) => ({ id: a && a.id, mid: a && a.mid, name: (a && (a.name || a.title)) || '' }))
    .filter((a) => a.name);
}

function mapQQSmartSong(item) {
  item = item || {};
  const mid = item.mid || item.songmid || item.id || '';
  return {
    provider: 'qq',
    source: 'qq',
    type: 'qq',
    id: mid,
    qqId: item.id || item.docid || '',
    mid,
    songmid: mid,
    name: item.name || item.songname || item.title || '',
    artist: item.singer || '',
    artists: item.singer ? [{ name: item.singer }] : [],
    album: item.albumname || '',
    cover: item.albumimg || '',
    duration: Number(item.duration || 0) * 1000,
    fee: 0,
    playable: false,
  };
}

function mapQQTrack(track, fallback) {
  track = track || {};
  fallback = fallback || {};
  const album = track.album || {};
  const artists = mapQQArtists(track.singer || []);
  const mid = track.mid || fallback.mid || fallback.songmid || '';
  const albumMid = album.mid || album.pmid || '';
  return {
    provider: 'qq',
    source: 'qq',
    type: 'qq',
    id: mid,
    qqId: track.id || fallback.qqId || fallback.id || '',
    mid,
    songmid: mid,
    mediaMid: (track.file && track.file.media_mid) || fallback.mediaMid || '',
    name: track.name || track.title || fallback.name || '',
    artist: artists.map((a) => a.name).join(' / ') || fallback.artist || '',
    artists: artists.length ? artists : fallback.artists || [],
    artistId: artists[0] && (artists[0].id || artists[0].mid),
    artistMid: artists[0] && artists[0].mid,
    album: album.name || album.title || fallback.album || '',
    albumMid,
    cover: qqAlbumCover(albumMid, 300) || fallback.cover || '',
    duration: (Number(track.interval) || 0) * 1000 || fallback.duration || 0,
    fee: track.pay && Number(track.pay.pay_play) ? 1 : 0,
    playable: false,
  };
}

async function qqMusicRequest(payload, cookieHeader) {
  const resp = await fetch(`${QQ_MUSICU_URL}?format=json`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8',
      Referer: 'https://y.qq.com/',
      'User-Agent': UA,
      Cookie: cookieHeader || '',
    },
    body: JSON.stringify(payload),
  });
  return resp.json();
}

async function qqGetJSON(url, params, cookieHeader) {
  const u = new URL(url);
  Object.entries(params || {}).forEach(([k, v]) => u.searchParams.set(k, String(v)));
  const resp = await fetch(u.toString(), {
    headers: {
      Referer: 'https://y.qq.com/',
      'User-Agent': UA,
      Cookie: cookieHeader || '',
    },
  });
  return parseJSONText(await resp.text());
}

async function qqSmartboxSearch(keywords, limit) {
  const u = new URL(QQ_SMARTBOX_URL);
  u.searchParams.set('format', 'json');
  u.searchParams.set('key', keywords);
  u.searchParams.set('g_tk', '5381');
  u.searchParams.set('loginUin', '0');
  u.searchParams.set('hostUin', '0');
  u.searchParams.set('inCharset', 'utf8');
  u.searchParams.set('outCharset', 'utf-8');
  u.searchParams.set('notice', '0');
  u.searchParams.set('platform', 'yqq.json');
  u.searchParams.set('needNewCode', '0');
  const resp = await fetch(u.toString(), { headers: { Referer: 'https://y.qq.com/', 'User-Agent': UA } });
  const json = parseJSONText(await resp.text());
  const items = json && json.data && json.data.song && json.data.song.itemlist;
  return (Array.isArray(items) ? items : [])
    .slice(0, Math.max(1, Math.min(limit || 8, 12)))
    .map(mapQQSmartSong);
}

async function qqSongDetail(mid, fallback, cookieHeader) {
  if (!mid) return fallback;
  const json = await qqMusicRequest({
    comm: { ct: 24, cv: 0 },
    songinfo: {
      module: 'music.pf_song_detail_svr',
      method: 'get_song_detail_yqq',
      param: { song_mid: mid },
    },
  }, cookieHeader);
  const data = json && json.songinfo && json.songinfo.data;
  return mapQQTrack(data && data.track_info, fallback);
}

function mapQQComment(raw) {
  raw = raw || {};
  const user = raw.commentnick || raw.nick || raw.user || {};
  const nickname = raw.nick || raw.commentnick || user.nickname || user.name || 'QQ 用户';
  const avatar = raw.headurl || raw.avatarurl || user.avatar || user.headurl || '';
  return {
    id: raw.commentid || raw.commentId || raw.id || '',
    content: decodeHtmlEntities(raw.rootcommentcontent || raw.commentcontent || raw.content || ''),
    likedCount: Number(raw.praisenum || raw.praise_num || raw.likedCount || 0) || 0,
    time: Number(raw.time || raw.pubtime || 0) || 0,
    user: {
      id: raw.uin || user.uin || '',
      nickname,
      avatar,
    },
  };
}

function firstPositiveNumberFrom(objects, keys) {
  for (const obj of objects) {
    if (!obj || typeof obj !== 'object') continue;
    for (const key of keys) {
      const value = Number(obj[key]);
      if (Number.isFinite(value) && value > 0) return value;
    }
  }
  return 0;
}

function normalizeQQVipFields(profileBody, vipQueryBody, cookieHeader) {
  const cookieObj = parseCookieString(cookieHeader);
  const data = (profileBody && (profileBody.data || profileBody.profile || profileBody.creator || profileBody.result)) || {};
  const creator = (data.creator || data.user || data.profile || data) || {};
  const vipInfo = data.vipInfo || data.vipinfo || data.vip || creator.vipInfo || creator.vipinfo || {};
  const vipQueryData = (vipQueryBody && (vipQueryBody.req_0 && vipQueryBody.req_0.data)) || vipQueryBody || {};
  const infoMap = vipQueryData.infoMap || vipQueryData.map_userinfo || vipQueryData.mapUserInfo || {};
  const uin = qqCookieUin(cookieHeader);
  const uinKeys = [String(uin), uin ? `0${uin}` : '', ...Object.keys(infoMap || {})];
  let queryInfo = null;
  for (const key of uinKeys) {
    if (key && infoMap && infoMap[key]) {
      queryInfo = infoMap[key];
      break;
    }
  }
  if (!queryInfo && infoMap && typeof infoMap === 'object') {
    const values = Object.values(infoMap);
    queryInfo = values.length ? values[0] : null;
  }
  const objects = [cookieObj, data, creator, vipInfo, queryInfo, vipQueryData].filter(Boolean);
  let vipType = firstPositiveNumberFrom(objects, [
    'vipType', 'vip_type', 'viptype', 'musicVipType', 'music_vip_type',
    'music_vip_level', 'green_vip_level', 'luxury_vip_level', 'iGreenDiamondLevel',
    'iVipLevel', 'iSuperVip', 'iHugeVip', 'uHugeVipMask', 'uVipMask',
  ]);
  const vipFlag = objects.some((obj) => {
    if (!obj) return false;
    const flag = obj.isVip ?? obj.is_vip ?? obj.vipFlag ?? obj.vipflag ?? obj.iVipFlag;
    return flag === true || Number(flag) > 0 || String(flag || '').toLowerCase() === 'true';
  });
  const hugeVip = objects.some((obj) => obj && (
    Number(obj.uHugeVipMask || obj.iHugeVip || obj.huge_vip || obj.iSuperVip || 0) > 0
  ));
  if (!vipType && (vipFlag || hugeVip)) vipType = hugeVip ? 7 : 1;
  const isVip = vipType > 0 || vipFlag || hugeVip;
  const vipLevel = isVip ? 'vip' : 'none';
  return {
    vipType: vipType || (isVip ? 1 : 0),
    vipLevel,
    isVip,
    isSvip: false,
    vipLabel: isVip ? 'QQ VIP' : '无VIP',
  };
}

function normalizeQQProfile(body, cookieHeader) {
  const uin = qqCookieUin(cookieHeader);
  const data = (body && (body.data || body.profile || body.creator || body.result)) || {};
  const creator = (data.creator || data.user || data.profile || data) || {};
  const profileNick = creator.nick || creator.nickname || creator.name || creator.hostname || creator.title || '';
  const profileAvatar = creator.headpic || creator.avatar || creator.avatarUrl || creator.logo || '';
  const cookieNick = qqCookieNickname(cookieHeader, uin);
  const nick = profileNick || cookieNick || '';
  const avatar = profileAvatar || qqCookieAvatar(cookieHeader, uin);
  const vip = normalizeQQVipFields(body, null, cookieHeader);
  return {
    provider: 'qq',
    loggedIn: !!(uin && qqCookieMusicKey(cookieHeader)),
    preview: false,
    userId: uin,
    uin,
    nickname: nick || (uin ? `QQ ${uin}` : 'QQ 音乐'),
    avatar,
    ...vip,
    hasCookie: !!cookieHeader,
    playbackKeyReady: !!qqCookiePlaybackKey(cookieHeader),
    profileSource: profileNick || profileAvatar ? 'qq-profile' : (cookieNick || avatar ? 'cookie' : 'fallback'),
  };
}

async function fetchQQProfileHomepage(uin, cookieHeader) {
  const u = new URL('https://c.y.qq.com/rsc/fcgi-bin/fcg_get_profile_homepage.fcg');
  u.searchParams.set('cid', '205360838');
  u.searchParams.set('userid', uin);
  u.searchParams.set('reqfrom', '1');
  u.searchParams.set('g_tk', '5381');
  u.searchParams.set('loginUin', uin);
  u.searchParams.set('hostUin', '0');
  u.searchParams.set('format', 'json');
  u.searchParams.set('inCharset', 'utf8');
  u.searchParams.set('outCharset', 'utf-8');
  u.searchParams.set('notice', '0');
  u.searchParams.set('platform', 'yqq.json');
  u.searchParams.set('needNewCode', '0');
  return qqGetJSON(u.origin + u.pathname, Object.fromEntries(u.searchParams.entries()), cookieHeader);
}

async function fetchQQVipQuery(uin, cookieHeader) {
  const musicKey = qqCookieMusicKey(cookieHeader);
  const comm = { uin, format: 'json', ct: musicKey ? 19 : 24, cv: 0 };
  if (musicKey) comm.authst = musicKey;
  return qqMusicRequest({
    comm,
    req_0: {
      module: 'userInfo.VipQueryServer',
      method: 'SRFVipQuery_V2',
      param: { uin_list: [String(uin)] },
    },
  }, cookieHeader);
}

export async function getQQLoginStatus(cookieHeader) {
  const uin = qqCookieUin(cookieHeader);
  const musicKey = qqCookieMusicKey(cookieHeader);
  const fallback = normalizeQQProfile(null, cookieHeader);
  if (!uin || !musicKey) {
    return { ...fallback, loggedIn: false };
  }
  let profileBody = null;
  let vipQueryBody = null;
  try {
    [profileBody, vipQueryBody] = await Promise.all([
      fetchQQProfileHomepage(uin, cookieHeader).catch(() => null),
      fetchQQVipQuery(uin, cookieHeader).catch(() => null),
    ]);
  } catch (_) {}
  const info = normalizeQQProfile(profileBody, cookieHeader);
  const vip = normalizeQQVipFields(profileBody, vipQueryBody, cookieHeader);
  const merged = {
    ...info,
    ...vip,
    vipType: Math.max(Number(info.vipType || 0), Number(vip.vipType || 0)) || (vip.isVip ? 1 : 0),
    isVip: !!(info.isVip || vip.isVip),
    vipLevel: (info.isVip || vip.isVip) ? 'vip' : 'none',
    vipLabel: (info.isVip || vip.isVip) ? 'QQ VIP' : '无VIP',
  };
  if (profileBody && (profileBody.code === 1000 || profileBody.result === 301)) {
    return { ...merged, profileUnavailable: true };
  }
  if (!merged.vipType && !merged.isVip && vipQueryBody) {
    merged.vipSource = 'vip-query';
  } else if (merged.vipType > 0) {
    merged.vipSource = profileBody ? 'qq-profile' : 'cookie';
  }
  return merged;
}

export async function handleQQSearch(keywords, limit, cookieHeader) {
  const base = await qqSmartboxSearch(keywords, limit);
  const detailed = await Promise.all(
    base.map(async (item) => {
      try {
        return await qqSongDetail(item.mid, item, cookieHeader);
      } catch (_) {
        return item;
      }
    }),
  );
  const seen = new Set();
  return detailed.filter((song) => {
    const key = song && (song.mid || song.id || `${song.name}|${song.artist}`);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return !!song.name;
  });
}

export async function handleQQSongUrl(mid, mediaMid, qualityPreference, cookieHeader) {
  const songmid = String(mid || '').trim();
  if (!songmid) return { provider: 'qq', url: '', error: 'MISSING_MID', message: 'Missing QQ song mid' };
  const guid = String(10000000 + Math.floor(Math.random() * 90000000));
  const uin = qqCookieUin(cookieHeader) || '0';
  const musicKey = qqCookieMusicKey(cookieHeader);
  const playbackKey = qqCookiePlaybackKey(cookieHeader);
  let fileMediaMid = String(mediaMid || '').trim();
  if (!fileMediaMid) {
    try {
      const detail = await qqSongDetail(songmid, {}, cookieHeader);
      fileMediaMid = String(detail && detail.mediaMid || '').trim();
    } catch (_) {}
  }
  const requestedQuality = normalizeQualityPreference(qualityPreference);
  const mediaIds = [];
  if (fileMediaMid) mediaIds.push(fileMediaMid);
  if (songmid && !mediaIds.includes(songmid)) mediaIds.push(songmid);
  const fileCandidates = mediaIds.flatMap((mediaId) =>
    qualityCandidatesFrom(requestedQuality, QQ_QUALITY_CANDIDATE_TEMPLATES)
      .map((item) => ({ ...item, mediaId, filename: item.prefix + mediaId + item.ext })),
  );
  const filenames = fileCandidates.map((item) => item.filename);
  const param = {
    guid,
    songmid: filenames.length ? filenames.map(() => songmid) : [songmid],
    songtype: filenames.length ? filenames.map(() => 0) : [0],
    uin,
    loginflag: 1,
    platform: '20',
  };
  if (filenames.length) param.filename = filenames;
  const comm = { uin, format: 'json', ct: musicKey ? 19 : 24, cv: 0, platform: 'yqq.json' };
  if (musicKey) comm.authst = musicKey;
  const json = await qqMusicRequest({
    comm,
    req_0: { module: 'vkey.GetVkeyServer', method: 'CgiGetVkey', param },
  }, cookieHeader);
  const data = json && json.req_0 && json.req_0.data;
  const infos = data && Array.isArray(data.midurlinfo) ? data.midurlinfo : [];
  const info = infos.find((item) => item && item.purl) || infos[0];
  const purl = info && info.purl;
  if (purl) {
    const sip = (data.sip && data.sip[0]) || 'https://ws.stream.qqmusic.qq.com/';
    const fileMeta = fileCandidates.find((item) => item.filename === info.filename) || {};
    return {
      provider: 'qq',
      url: sip + purl,
      trial: false,
      playable: true,
      level: fileMeta.level || info.filename || '',
      quality: fileMeta.label || info.filename || '',
      filename: info.filename || '',
      requestedQuality,
      playbackKeyReady: !!(uin && playbackKey),
      loggedIn: !!(uin && musicKey),
    };
  }
  const restriction = classifyQQPlaybackRestriction(info, {
    hasSession: !!(uin && musicKey),
    hasPlaybackKey: !!(uin && playbackKey),
  });
  return {
    provider: 'qq',
    url: '',
    playable: false,
    error: 'QQ_URL_UNAVAILABLE',
    loggedIn: !!(uin && musicKey),
    playbackKeyReady: !!(uin && playbackKey),
    restriction,
    reason: restriction.category,
    message: restriction.message,
    qqCode: info && (info.result || info.code || info.errtype),
    rawMessage: info && (info.msg || info.tips || info.errmsg || ''),
    tried: fileCandidates.map((item) => item.label + ' · ' + item.filename),
    requestedQuality,
  };
}

export async function handleQQArtistDetail(mid, limit, cookieHeader) {
  const singerMid = String(mid || '').trim();
  const num = Math.max(10, Math.min(80, Number(limit) || 36));
  if (!singerMid) return { provider: 'qq', error: 'MISSING_SINGER_MID', artist: null, songs: [] };
  const json = await qqMusicRequest({
    comm: { ct: 24, cv: 0 },
    singer: {
      module: 'music.web_singer_info_svr',
      method: 'get_singer_detail_info',
      param: { sort: 5, singermid: singerMid, sin: 0, num },
    },
  }, cookieHeader);
  const block = json && json.singer;
  if (!block || Number(block.code || 0) !== 0) {
    return {
      provider: 'qq',
      error: (block && (block.message || block.msg || block.code)) || 'QQ_ARTIST_DETAIL_FAILED',
      artist: null,
      songs: [],
    };
  }
  const data = block.data || {};
  const info = data.singer_info || data.singerInfo || {};
  const rawSongs = Array.isArray(data.songlist) ? data.songlist : [];
  const songs = rawSongs
    .map((raw) => mapQQTrack(raw && (raw.track_info || raw.songInfo || raw.songinfo || raw.song) || raw, {}))
    .filter((song) => song && song.name && (song.mid || song.id));
  const artistMid = info.mid || singerMid;
  return {
    provider: 'qq',
    artist: {
      provider: 'qq',
      id: info.id || '',
      mid: artistMid,
      name: info.name || info.title || '',
      avatar: info.pic || info.avatar || qqSingerAvatar(artistMid, 300),
      fans: Number(info.fans || 0) || 0,
      musicSize: Number(data.total_song || data.song_count || 0) || songs.length,
    },
    total: Number(data.total_song || data.song_count || 0) || songs.length,
    songs,
  };
}

export async function handleQQSongComments(id, mid, limit, offset, cookieHeader) {
  let topid = String(id || '').replace(/\D/g, '');
  if (!topid && mid) {
    try {
      const detail = await qqSongDetail(mid, { mid }, cookieHeader);
      topid = String((detail && (detail.qqId || detail.id)) || '').replace(/\D/g, '');
    } catch (_) {}
  }
  if (!topid) return { provider: 'qq', error: 'Missing QQ song id', comments: [] };
  try {
    const page = Math.max(0, Math.floor((offset || 0) / Math.max(1, limit || 20)));
    const uin = qqCookieUin(cookieHeader) || '0';
    const body = await qqGetJSON('https://c.y.qq.com/base/fcgi-bin/fcg_global_comment_h5.fcg', {
      g_tk: '5381',
      loginUin: uin,
      hostUin: '0',
      format: 'json',
      inCharset: 'utf8',
      outCharset: 'utf-8',
      notice: '0',
      platform: 'yqq.json',
      needNewCode: '0',
      cid: '205360772',
      reqtype: '2',
      biztype: '1',
      topid,
      cmd: '8',
      needmusiccrit: '0',
      pagenum: String(page),
      pagesize: String(limit || 20),
    }, cookieHeader);
    const hotList = body && body.hot_comment && body.hot_comment.commentlist;
    const normalList = body && body.comment && body.comment.commentlist;
    const raw = offset === 0 && Array.isArray(hotList) && hotList.length ? hotList : normalList || [];
    const comments = raw.map(mapQQComment).filter((c) => c.content);
    const total = Number(body && body.comment && (body.comment.commenttotal || body.comment.comment_total)) || comments.length;
    return { provider: 'qq', id: topid, total, comments, hot: !!(offset === 0 && Array.isArray(hotList) && hotList.length) };
  } catch (err) {
    return { provider: 'qq', error: err.message || String(err), id: topid, comments: [] };
  }
}

async function resolveQQSongNumericId(id, mid, cookieHeader) {
  let songId = String(id || '').replace(/\D/g, '');
  if (!songId && mid) {
    try {
      const detail = await qqSongDetail(mid, { mid }, cookieHeader);
      songId = String((detail && (detail.qqId || detail.id)) || '').replace(/\D/g, '');
    } catch (_) {}
  }
  return songId;
}

export async function handleQQSongLikeCheck(ids, cookieHeader) {
  const status = await getQQLoginStatus(cookieHeader);
  const liked = {};
  if (!status.loggedIn) return { provider: 'qq', error: 'LOGIN_REQUIRED', loggedIn: false, liked, ids };
  const uin = status.uin || qqCookieUin(cookieHeader);
  let likedSet = new Set();
  try {
    const json = await qqMusicRequest({
      comm: { uin, format: 'json' },
      req_0: {
        module: 'music.musicasset.SongFavRead',
        method: 'GetSongIdList',
        param: { uin: Number(uin) || uin, dirId: 201 },
      },
    }, cookieHeader);
    const list = (((json.req_0 || {}).data || {}).songIds) || (((json.req_0 || {}).data || {}).songIdList) || [];
    likedSet = new Set(list.map(String));
  } catch (_) {}
  (ids || []).forEach((id) => {
    const key = String(id || '').replace(/\D/g, '');
    liked[id] = likedSet.has(key);
  });
  return { provider: 'qq', loggedIn: true, ids, liked };
}

export async function handleQQSongLike(id, mid, like, cookieHeader) {
  const status = await getQQLoginStatus(cookieHeader);
  if (!status.loggedIn) return { provider: 'qq', error: 'LOGIN_REQUIRED', loggedIn: false };
  const songId = await resolveQQSongNumericId(id, mid, cookieHeader);
  if (!songId) return { provider: 'qq', error: 'MISSING_QQ_SONG_ID', loggedIn: true };
  const uin = status.uin || qqCookieUin(cookieHeader);
  const json = await qqMusicRequest({
    comm: { uin, format: 'json' },
    req_0: {
      module: 'music.musicasset.SongFavWrite',
      method: like !== false ? 'AddSong' : 'DelSong',
      param: {
        uin: Number(uin) || uin,
        v_uin: Number(uin) || uin,
        dirId: 201,
        ids: [Number(songId)],
      },
    },
  }, cookieHeader);
  const block = json.req_0 || {};
  const blockData = block.data || {};
  const code = Number(block.code ?? blockData.code ?? json.code ?? 0);
  if (code && code !== 0 && code !== 200) {
    return {
      provider: 'qq',
      error: (block.data && (block.data.msg || block.data.message)) || block.msg || 'QQ_LIKE_FAILED',
      loggedIn: true,
      id: songId,
      mid: mid || '',
      liked: false,
      code,
    };
  }
  return { provider: 'qq', loggedIn: true, id: songId, mid: mid || '', liked: like !== false, code: code || 0 };
}

export async function handleQQUserPlaylists(cookieHeader) {
  const status = await getQQLoginStatus(cookieHeader);
  if (!status.loggedIn) return { loggedIn: false, playlists: [] };
  const uin = status.uin || '0';
  const json = await qqMusicRequest({
    comm: { uin, format: 'json' },
    req_0: { module: 'libPersonal.PersonalSvr', method: 'GetPlaylist', param: { uin, req_num: 30 } },
  }, cookieHeader);
  const list = (((json.req_0 || {}).data || {}).cdlist) || [];
  const playlists = list.map((pl) => ({
    id: pl.dissid || pl.dirid,
    qqId: pl.dissid || pl.dirid,
    name: pl.dissname || pl.title || '',
    cover: pl.logo || pl.picurl || '',
    trackCount: pl.songnum || pl.total_song_num || 0,
    creator: pl.nickname || '',
    provider: 'qq',
  }));
  return { loggedIn: true, playlists, provider: 'qq' };
}

export async function handleQQPlaylistTracks(id, cookieHeader) {
  const json = await qqMusicRequest({
    comm: { format: 'json' },
    req_0: {
      module: 'playlist.PlayListPlazaServer',
      method: 'GetPlaylistById',
      param: { id: Number(id) || id, num: 80, onlysong: 1 },
    },
  }, cookieHeader);
  const data = (json.req_0 || {}).data || {};
  const songs = (data.songlist || []).map((item) => mapQQTrack(item, {}));
  const meta = {
    id,
    name: data.title || data.diss_title || '',
    cover: data.picurl || data.logo || '',
    trackCount: songs.length,
    provider: 'qq',
  };
  return {
    ...meta,
    playlist: meta,
    tracks: songs,
    songs,
    provider: 'qq',
  };
}

export async function handleQQLyric(mid, id, cookieHeader) {
  const songMID = String(mid || '').trim();
  const songID = String(id || '').replace(/\D/g, '');
  if (!songMID && !songID) return { provider: 'qq', error: 'Missing QQ song mid or id', lyric: '' };
  let lyricText = '';
  let transText = '';
  try {
    const param = {};
    if (songMID) param.songMID = songMID;
    if (songID) param.songID = Number(songID);
    const json = await qqMusicRequest({
      comm: { ct: 24, cv: 0 },
      lyric: {
        module: 'music.musichallSong.PlayLyricInfo',
        method: 'GetPlayLyricInfo',
        param,
      },
    }, cookieHeader);
    const data = json && json.lyric && json.lyric.data;
    lyricText = decodeQQLyricText(data && data.lyric);
    transText = decodeQQLyricText(data && data.trans);
  } catch (_) {}
  if (!lyricText && songMID) {
    try {
      const body = await qqGetJSON('https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg', {
        songmid: songMID,
        songtype: '0',
        format: 'json',
        nobase64: '1',
        g_tk: '5381',
        loginUin: qqCookieUin(cookieHeader) || '0',
        hostUin: '0',
        inCharset: 'utf8',
        outCharset: 'utf-8',
        notice: '0',
        platform: 'yqq.json',
        needNewCode: '0',
      }, cookieHeader);
      lyricText = decodeQQLyricText(body && body.lyric);
      transText = decodeQQLyricText(body && (body.trans || body.tlyric)) || transText;
    } catch (_) {}
  }
  return {
    provider: 'qq',
    id: songID,
    mid: songMID,
    lyric: lyricText,
    tlyric: transText,
    yrc: '',
    source: lyricText ? 'qq-extension' : 'qq-empty',
  };
}

export { getQQCookie, mapQQTrack, qqSongDetail };
