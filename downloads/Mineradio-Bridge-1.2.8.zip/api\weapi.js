export const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

export async function weapiRequest() {
  throw new Error('weapiRequest is deprecated; use eapiRequest');
}
